# post-wordcount

 * Plugin Name: Post Word Count in Admin List
 * Plugin URI:  https://github.com/vestrainteractive/post-wordcount
 * Description: Adds a column to the posts list displaying the word count of each post.
 * Version: 1.0
 * Author: Vestra Interactive
 * Author URI: https://vestrainteractive.com
 * License: GPLv2 or later
 * 
Adds a column to the posts list displaying the word count of each post.

To use:

Simply upload and activate the plugin.
